
/*****环境配置*****/
//测试地址
var kBaseUrl = 'https://jiekouhd.0256.cn:8491';
var KHtmlUrl = 'https://testh5.0256.cn';


//生产地址
//var kBaseUrl = 'https://tcappjk.0256.cn';
//var KHtmlUrl = 'https://h5.0256.cn';

