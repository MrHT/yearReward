//通用接口请求

var outTime = 10000; //设置接口请求过期时间

//get统一接口请求方法
function GETHttpHelper(url, param, successCallBack, errorCallBack) {
	console.log('接口地址url=' + url);
	console.log('请求方式=' + 'GET');
	console.log('请求参数param=' + JSON.stringify(param));
	mui.ajax(url, {
		data: param,
		dataType: 'json',
		type: 'get',
		timeout: outTime,
		success: function(successData) {
			
			console.log('返回数据=' + JSON.stringify(successData));
			successCallBack(successData);
		},
		error: function(xhr, type, errorThrown) {
			errorCallBack('错误信息=' + xhr+","+type+","+errorThrown);
			console.log('错误信息=' + xhr+","+type+","+errorThrown);
		}
	})
}
//post统一接口请求方法
function POSTHttpHelper(url, param, successCallBack, errorCallBack) {
	console.log('接口地址url=' + url);
	console.log('请求方式=' + 'POST');
	console.log('请求参数param=' + JSON.stringify(param));
	mui.ajax(url, {
		data: param,
		type: 'post',
		timeout: outTime,
		dataType: 'json',
		success: function(successData) {
			successCallBack(successData);
			console.log('返回数据=' + JSON.stringify(successData));
		},
		error: function(xhr, type, errorThrown) {
			errorCallBack('错误信息=' + xhr+","+type+","+errorThrown);
			console.log('错误信息=' + xhr+","+type+","+errorThrown);
		}
	})
}