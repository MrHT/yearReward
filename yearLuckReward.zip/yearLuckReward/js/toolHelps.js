
document.write('<script type="text/javascript" src="js/rem.js" ></script>');
var loadingHint = '<div class="loading" style="width: 100%; height: 100%; background: rgba(0,0,0,0); position: absolute;left: 0; top: 0;">' +
					'<div class="loading-box" style="width:2.0rem; height:2.0rem;position: absolute; top: 50%;left: 50%;padding:0.37rem;margin-left: -1.11rem;margin-top: -1.11rem; border-radius: 0.18rem; background: rgba(0,0,0,0.6);">'+
						'<img src="./images/loading.gif" alt=""  style="width: 1.28rem; height: 1.28rem;"/></div></div>';
	
								
//显示加载动画
function loadingShow(){
	console.log('loading');
	var  newNode=  document.createElement("div");//创建新节点
	newNode.id = 'loading';
	newNode.innerHTML = loadingHint;
	document.body.appendChild(newNode);
	
	
}
//关闭加载动画
function loadingHide(){
	var hide =  document.getElementById('loading');
	document.body.removeChild(hide);
}

//获取链接中的参数
function getValueFromURL() {
       var url = window.location.search; //获取url中"?"符后的字串   
       var theRequest = new Object();   
       if (url.indexOf("?") != -1) {   
          var str = url.substr(1);
          strs = str.split("&");   
          for(var i = 0; i < strs.length; i ++) {   
              //就是这句的问题
             theRequest[strs[i].split("=")[0]]=decodeURI(strs[i].split("=")[1]); 
             //之前用了unescape()
             //才会出现乱码  
          }   
       }   
       return theRequest;   
    }